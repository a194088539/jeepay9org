﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace jeepay
{
    public partial class callback : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            ukey = "tBc6Kc4GforyYMd92VO96Dd3s4D1Uedg4U79VBFoSCyIcxXig5HifX6LVXUFWankOJe6HB2wjtFAEohvfA6XCVltlox4FKboCd5K165rn3tTd3H5iaqpmn9KI6G3rBeA";
            String[] ParmList = new String[] { "payOrderId", "amount", "mchId", "income", "productId", "mchOrderNo", "paySuccTime", "channelOrderNo", "backType", "status", "appId" };

            SortedDictionary<string, string> DataContentParms = new SortedDictionary<string, string>();
            foreach (String key in ParmList)
            {
                DataContentParms.Add(key, Request.Params[key]);
            }
            String SignStr = Request.Params["sign"];


            string FormString = "";
            string data = "";
            foreach (string key in DataContentParms.Keys)
            {
                FormString += DataContentParms[key];
                data += key + "=" + DataContentParms[key] + "&";

            }

            string signa = Utils.MD5(data + "key=" + ukey, false).ToUpper();

            if (SignStr == signa && Request.Params["status"] == "2")
            {
                HttpContext.Current.Response.Write("SUCCESS");

            }
            else {
                HttpContext.Current.Response.Write("签名失败");
            }
        }




        public string ukey { get; set; }
    }
}