﻿<?php
require_once("ApiBase.php");


$ApiBase = new ApiBase();
$key = 'tBc6Kc4GforyYMd92VO96Dd3s4D1Uedg4U79VBFoSCyIcxXig5HifX6LVXUFWankOJe6HB2wjtFAEohvfA6XCVltlox4FKboCd5K165rn3tTd3H5iaqpmn9KI6G3rBeA';



$data = array(
	'payOrderId' => $_REQUEST['payOrderId'],//开户账号
	'amount' => $_REQUEST['amount'], //alipay:支付宝,tenpay:财付通,qqpay:QQ钱包,wxpay:微信支付 
	'mchId' => $_REQUEST['mchId'],
	'income' => $_REQUEST['income'],
	'productId' => $_REQUEST['productId'],
	'mchOrderNo' => $_REQUEST['mchOrderNo'],
	'paySuccTime' => $_REQUEST['paySuccTime'],
	'sign' => $_REQUEST['sign'],
	'channelOrderNo' => $_REQUEST['channelOrderNo'],
	'backType' => $_REQUEST['backType'],
	'status' => $_REQUEST['status'],
	'appId'=>$_REQUEST['appId']
);

//验证签名
$ApiBase->CheckRequestSign($data, $key);

//签名验证通过
//判断该笔订单是否在商户网站中已经做过处理
//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
//如果有做过处理，不执行商户的业务程序
//返回参数
//order_sn 平台订单号
//out_trade_no 商家订单号
//total_fee 订单金额
//trade_status 支付状态,SUCCESS代表支付成功
//异步通知商家处理成功返回，请返回 SUCCESS
echo 'SUCCESS';