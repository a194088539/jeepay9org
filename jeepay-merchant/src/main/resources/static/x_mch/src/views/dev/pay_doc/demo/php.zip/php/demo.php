<?php

require_once("ApiBase.php");

$ApiBase = new ApiBase();

//下订单支付
$data = array(
	'mchId' => '20000000',							 // 商户ID
	'appId' => "7ca36fb15e8943b79d098ce8a36aec0a",	 // 应用ID
	'productId' => 8018,							 // 支付产品
	'mchOrderNo' => '1577629826865',				 // 商户订单号
	'currency'=> 'cny',								 // 币种, cny-人民币
	'amount' => 5000,								 // 支付金额,单位分
	'clientIp'=> '211.94.116.218',					 // 用户地址,微信H5支付时要真实的
	'device'=> 'WEB',								 // 设备
	'notifyUrl' => 'http://www.baidu.com',			 // 回调URL
	'returnUrl' => 'http://www.baidu.com',			 // 同步URL
	'subject'=> '话费充值',							 // 商品标题
	'body' => '话费充值',							 // 商品内容
	'param1' => '',                                  // 扩展参数1
	'param2' => '',                                  // 扩展参数2
	'extra'=>'{\"productId\":\"100\"}', 			 // 附加参数
);

//密钥
$key = 'D4SZ8TQK1Z8UPYMOLSKQQPMWYKVXW8IAHBMNJEFXJLCYPF7AWKCTKN1SXWS82ZNPMOBRFEGCK5TOGOQKPC59LP0FHIP6TU5GZ5TZXHHJ7YDGHSWP2URHZX1YUKPUMPAM';

//签名
$para = $ApiBase->buildRequestPara($data, $key);

$url = 'http://192.74.225.9:53020/api/pay/create_order?';
        

$curl = curl_init($url);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);//SSL证书认证
curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);//严格认证
//curl_setopt($curl, CURLOPT_CAINFO,$cacert_url);//证书地址
curl_setopt($curl, CURLOPT_HEADER, 0 ); // 过滤HTTP头
curl_setopt($curl,CURLOPT_RETURNTRANSFER, 1);// 显示输出结果
curl_setopt($curl,CURLOPT_POST,true); // post传输数据
curl_setopt($curl,CURLOPT_POSTFIELDS,'params='.json_encode($para));// post传输数据
$responseText = curl_exec($curl);
//var_dump( curl_error($curl) );//如果执行curl过程中出现异常，可打开此开关，以便查看异常内容
curl_close($curl);

echo $responseText;


