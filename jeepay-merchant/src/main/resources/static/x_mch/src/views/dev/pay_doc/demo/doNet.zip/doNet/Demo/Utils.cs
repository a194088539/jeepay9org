﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace jeepay
{
    public class Utils
    {


        /// <summary>
        /// Post请求，可定义Headers
        /// </summary>
        /// <param name="Url">请求地址</param>
        /// <param name="PostData">Post参数:page=1&rows=2</param>
        /// <returns></returns>application/json;charset=UTF-8  application/x-www-form-urlencoded
        public static string HttpPost(string Url, string PostData, string contentType = "application/x-www-form-urlencoded", System.Collections.Generic.Dictionary<string, string> headerList = null)
        {
            int status = 0;
            string result = "";
            byte[] data = Encoding.UTF8.GetBytes(PostData);

            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create(Url);

            httpRequest.ServicePoint.ConnectionLimit = 512;
            httpRequest.Method = "POST";
            httpRequest.ContentType = contentType;
            httpRequest.ContentLength = data.Length;

            if (headerList != null)
            {
                foreach (string key in headerList.Keys)
                {
                    httpRequest.Headers.Add(key, headerList[key]);
                }
            }

            using (Stream newStream = httpRequest.GetRequestStream())
            {
                newStream.Write(data, 0, data.Length);
                newStream.Close();
            }
            using (HttpWebResponse httpResponse = (HttpWebResponse)httpRequest.GetResponse())
            {
                using (StreamReader reqStream = new StreamReader(httpResponse.GetResponseStream(), Encoding.UTF8))
                {
                    result = reqStream.ReadToEnd();

                    status = (int)httpResponse.StatusCode;

                    reqStream.Close();
                }

                httpRequest.Abort();
                httpResponse.Close();
            }

            return result;
        }

        public static string getRandom()
        {
          
            {
                Random ran = new Random();
                return DateTime.Now.ToString("yyyyMMddHHmmssfff") + ran.Next(1000, 9999).ToString();
            }
        }

        public static string MD5(string str, bool half)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(str);
            bytes = new MD5CryptoServiceProvider().ComputeHash(bytes);
            string str2 = "";
            for (int i = 0; i < bytes.Length; i++)
            {
                str2 = str2 + bytes[i].ToString("x").PadLeft(2, '0');
            }
            if (half)
            {
                str2 = str2.Substring(8, 0x10);
            }
            return str2;
        }
    }
}