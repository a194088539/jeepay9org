<?php
// +----------------------------------------------------------------------
// | Copyright (c) 2018  All rights reserved.
// +----------------------------------------------------------------------
// | Author: wangkun
// +----------------------------------------------------------------------
// | ApiBase.php Date: 2018-4-14
// +----------------------------------------------------------------------
// | Explain: 接口签名类
// +----------------------------------------------------------------------


class ApiBase
{

	/**
	 * 签名字符串
	 * @param $prestr 需要签名的字符串
	 * @param $key 私钥
	 * return 签名结果
	 */
	function md5Sign($prestr, $key) {
		$prestr = $prestr . '&key='.$key;
		return strtoupper(md5($prestr));
	}


	/**
	 * 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
	 * @param $para 需要拼接的数组
	 * return 拼接完成以后的字符串
	 */
	function createLinkstring($para) {
		$arg  = "";
		while (list ($key, $val) = each ($para)) {
			$arg.=$key."=".$val."&";
		}
		//去掉最后一个&字符
		$arg = substr($arg,0,count($arg)-2);
		
		//如果存在转义字符，那么去掉转义
		if(get_magic_quotes_gpc()){$arg = stripslashes($arg);}
		
		return $arg;
	}


	/**
	 * 除去数组中的空值和签名参数
	 * @param $para 签名参数组
	 * return 去掉空值与签名参数后的新签名参数组
	 */
	function paraFilter($para) {
		$para_filter = array();
		foreach($para as $key => $val){
			if($key == "sign" || $val == ""){
				continue;
			}else{
				$para_filter[$key] = $para[$key];
			}
		}
		return $para_filter;
	}

	/**
	 * 对数组排序
	 * @param $para 排序前的数组
	 * return 排序后的数组
	 */
	function argSort($para) {
		ksort($para);
		reset($para);
		return $para;
	}

		
	/**
	 * 生成签名结果
	 * @param $para_sort 已排序要签名的数组
	 * return 签名结果字符串
	 */
	function buildRequestMysign($para_sort, $key) {
		//把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
		$prestr = $this->createLinkstring($para_sort);
		
		$mysign = $this->md5Sign($prestr, $key);

		return $mysign;
	}

	/**
     * 生成带签名的参数数组
     * @param $para_temp 请求前的参数数组
	 * @param $key 请求的用户key
     * @return 要请求的参数数组
     */
	function buildRequestPara($para_temp, $key) {
		//除去待签名参数数组中的空值和签名参数
		$para_filter = $this->paraFilter($para_temp);

		//对待签名参数数组排序
		$para_sort = $this->argSort($para_filter);

		//生成签名结果
		$mysign = $this->buildRequestMysign($para_sort, $key);
		
		//签名结果与签名方式加入请求提交参数组中
		$para_sort['sign'] = $mysign;
		
		return $para_sort;
	}

	/*
	 * 验证带签名的参数数组
	 */
	public function CheckRequestSign($data_sign, $key){
		//除去待签名参数数组中的空值和签名参数
		$para_filter = $this->paraFilter($data_sign);

		//对待签名参数数组排序
		$para_sort = $this->argSort($para_filter);

		//把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
		$prestr = $this->createLinkstring($para_sort);
		
		$check = $this->md5Verify($prestr, $data_sign['sign'], $key);	
		
		if(!$check){
			echo '签名错误';
			exit;
		}
	}

	/**
	 * 验证签名
	 * @param $prestr 需要签名的字符串
	 * @param $sign 签名结果
	 * @param $key 私钥
	 * return 签名结果
	 */
    public function md5Verify($prestr, $sign, $key) {
		$prestr = $prestr . '&key='. $key;
		$mysgin =strtoupper(md5($prestr));

		if($mysgin == $sign) {
			return true;
		}
		else {
			return false;
		}
	}

	
}