package com.jeepay.demo.util;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jeepay.demo.support.http.HttpHandler;
import com.jeepay.demo.support.http.httpclient.HttpClientHandler;
import com.jeepay.demo.support.http.httpclient.RemoteSetting;

/**
 * Http请求工具类
 * <p>说明:</p>
 * <li>post请求</li>
 * <li>get请求</li>
 * @author DuanYong
 * @since 2018年12月19日上午10:49:03
 */
public class HttpUtils {
    protected static final Logger logger = LoggerFactory.getLogger(HttpUtils.class);

    private static HttpHandler httpHandler = null;
    
    private static class HttpClientHolder {
		/**
		 * 静态初始化器，由JVM来保证线程安全
		 */
		private static HttpUtils instance = new HttpUtils();
	}
    private HttpUtils() {
    	httpHandler = new HttpClientHandler(new RemoteSetting());
    }
    public static HttpUtils getInstance() {
		return HttpClientHolder.instance;
	}
    /**
     * post请求
     * <p>说明:</p>
     * <li></li>
     * @author DuanYong
     * @param address 请求地址
     * @param data 参数
     * @return 响应数据
     * @since 2018年12月19日上午10:47:28
     */
    public String post(String address,Map<String,Object> data){
    	return httpHandler.post(address, data);
    }
    /**
     * get请求
     * <p>说明:</p>
     * <li></li>
     * @author DuanYong
     * @param address 地址
     * @return 响应数据
     * @since 2018年12月19日上午10:48:07
     */
    public String get(String address){
    	return httpHandler.get(address);
    }
}
