﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace jeepay
{
    public partial class index : System.Web.UI.Page
    {
        private string ukey;
  
        protected void Page_Load(object sender, EventArgs e)
        {
           ukey = "D4SZ8TQK1Z8UPYMOLSKQQPMWYKVXW8IAHBMNJEFXJLCYPF7AWKCTKN1SXWS82ZNPMOBRFEGCK5TOGOQKPC59LP0FHIP6TU5GZ5TZXHHJ7YDGHSWP2URHZX1YUKPUMPAM";
           SortedDictionary<string, string> DataContentParms = new SortedDictionary<string, string>();
            DataContentParms["mchId"] = "20000000";							//商户ID
            DataContentParms["appId"] = "7ca36fb15e8943b79d098ce8a36aec0a"; //应用ID
            DataContentParms["productId"] = "8018";							//支付产品ID
            DataContentParms["mchOrderNo"] = Utils.getRandom();			    //商户订单号
            DataContentParms["currency"] = "cny";							//币种
            DataContentParms["amount"] = "5000";							//支付金额,单位(分)
            DataContentParms["clientIp"] = "210.73.10.148";					//用户地址,微信H5支付时要真实的
            DataContentParms["device"] = "WEB";								//设备
            DataContentParms["notifyUrl"] = "http://www.baidu.com";			//支付结果异步回调URL
            DataContentParms["returnUrl"] = "http://www.baidu.com";			//支付结果同步回调URL
            DataContentParms["subject"] ="话费充值";						//商品主题
            DataContentParms["body"] = "话费充值";						//商品描述信息
            DataContentParms["param1"] = "";								//支付结果异步回调URL
            DataContentParms["param2"] = "";								//支付结果同步回调URL
            DataContentParms["extra"] = "{\"productId\":\"100\"}";			//附加参数

            string FormString = "";
            string data = "";
            foreach (string key in DataContentParms.Keys)
            {
                FormString += DataContentParms[key];
                data += key + "=" + DataContentParms[key] + "&";

            }
      
            string signa = Utils.MD5(data+"key="+ukey,false).ToUpper();
            DataContentParms["sign"] = signa;
            string json = JsonConvert.SerializeObject(DataContentParms);

            string fbody = Utils.HttpPost("http://192.74.225.9:53020/api/pay/create_order?", "params=" + json);

            JObject jsonObj = JObject.Parse(fbody);

            if (jsonObj["retCode"].ToString() == "SUCCESS")
            {

                HttpContext.Current.Response.Redirect(jsonObj["payUrl"].ToString());

            }
        //    HttpContext.Current.Response.Write(fbody);
           // HttpContext.Current.Response.Write(json);
        }

    }
}