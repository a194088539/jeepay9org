package com.jeepay.demo.support.http.httpclient;
/**
 * 远程配置
 * <p>说明:</p>
 * <li></li>
 * @author DuanYong
 * @since 2018年12月19日上午10:25:13
 */
public class RemoteSetting {
	/** 连接池最大并发连接数,默认值*/
	public static final int DEFAULT_MAX_TOTAL = 300;
	/** 连接池最大并发连接数,默认值*/
	public static final int DEFAULT_MAX_ROUTE = 50;
	/** 数据传输处理时间,默认值*/
	public static final int DEFAULT_SOCKET_TIMEOUT = 4 * 1000;
	/** 建立连接的timeout时间,默认值*/
	public static final int DEFAULT_CONN_TIMEOUT = 3 * 1000;
	/** 从连接池中获取连接的timeout时间,默认值*/
	public static final int DEFAULT_CONN_REQ_TIMEOUT = 1 * 1000;
	
	/**连接池最大并发连接数*/
	private  int maxTotal = DEFAULT_MAX_TOTAL;
	/**单路由最大并发数*/
	private  int defaultMaxPerRoute = DEFAULT_MAX_ROUTE;
    /**数据传输处理时间*/
	private int socketTimeout = DEFAULT_SOCKET_TIMEOUT;
	/**建立连接的timeout时间*/
	private int connectionTimeout = DEFAULT_CONN_TIMEOUT;
	/**从连接池中获取连接的timeout时间*/
	private int connectionRequestTimeout = DEFAULT_CONN_REQ_TIMEOUT;
	
	public int getMaxTotal() {
		return maxTotal;
	}
	public void setMaxTotal(int maxTotal) {
		this.maxTotal = maxTotal;
	}
	public int getDefaultMaxPerRoute() {
		return defaultMaxPerRoute;
	}
	public void setDefaultMaxPerRoute(int defaultMaxPerRoute) {
		this.defaultMaxPerRoute = defaultMaxPerRoute;
	}
	public int getSocketTimeout() {
		return socketTimeout;
	}
	public void setSocketTimeout(int socketTimeout) {
		this.socketTimeout = socketTimeout;
	}
	public int getConnectionTimeout() {
		return connectionTimeout;
	}
	public void setConnectionTimeout(int connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}
	public int getConnectionRequestTimeout() {
		return connectionRequestTimeout;
	}
	public void setConnectionRequestTimeout(int connectionRequestTimeout) {
		this.connectionRequestTimeout = connectionRequestTimeout;
	}
	
	
}
